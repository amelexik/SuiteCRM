<?php 
$app_list_strings['sale_status'] = array (
  'contact' => 'проконтактировать',
  'contact_established' => 'контакт установлен',
  'interested' => 'заинтересованы',
  'presentation_made' => ' презентация проведена',
  'project_evaluation' => 'оценка проекта',
  'pilot_started' => 'пилот начат',
  'project_negotiations' => 'переговоры по проекту',
  'client' => 'клиент',
  'ex_client' => 'клиент бывший',
  'deferred_need' => 'отложенная потребность',
  'cancel' => 'отказ',
  'danger' => 'не контактировать',
);