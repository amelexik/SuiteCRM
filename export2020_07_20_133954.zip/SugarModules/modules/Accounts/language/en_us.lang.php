<?php 
 // created: 2020-07-20 13:39:53
$mod_strings['LBL_SALE_STATUS'] = 'Sale Status';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'New Panel 1';

?>
