<?php
 // created: 2020-07-17 23:00:42
$dictionary['Account']['fields']['sale_status_c']['inline_edit']='1';
$dictionary['Account']['fields']['sale_status_c']['labelValue']='Sale Status';

 ?>