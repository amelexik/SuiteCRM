<?php
 // created: 2020-07-17 21:51:13
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>